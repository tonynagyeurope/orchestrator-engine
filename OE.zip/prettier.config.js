export default {
  semi: true,
  singleQuote: false,
  trailingComma: "es5",
  printWidth: 90,
  tabWidth: 2,
  endOfLine: "lf",
};
