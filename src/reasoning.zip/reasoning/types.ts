// src/reasoning/types.ts

import { OrchestratorProfile } from "../config/baseConfig.js";

export interface ReasoningProvider {
  id: string;
  analyze(
    input: string,
    profile: string | OrchestratorProfile,
    options?: Record<string, unknown>
  ): Promise<ReasoningResult>;
}

export interface ReasoningResult {
  summary: string;
  steps: string[];
  meta?: Record<string, unknown>;
}